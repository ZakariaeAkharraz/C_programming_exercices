#include <stdio.h>


int longueur_chain1(char ctab1[]){
    int count=0;
    while (ctab1[count]!='\0')
    {
        count++;
    }
    return count;
}

int main(){
char ctab1[]="ladies and gentlment";
char ctab2[]="Medames et Mesieurs";
printf("\nle nombre de caracteres dans ctab1: %d",longueur_chain1(ctab1));
printf("\nle nombre de caracteres dans ctab2: %d",longueur_chain1(ctab2));


//crypted_nam=(char*)malloc(sizeof(char)*strlen(name));


}