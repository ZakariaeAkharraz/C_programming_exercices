#include <stdio.h>
#include <stdlib.h>
void saisie(int tab[],int elements){
    for (int i = 0; i < elements; i++)
    {
        printf("\nenter number %d : ",i+1);
        scanf("%d",tab+i);
    }
    
}
void Affichage(int *tab,int elements){
    
    for (int i = 0; i < elements; i++)
    {
        printf("\nnumber %d : %d",i+1,*(tab+i));
        
    }
    
}
int * SupMax(int *tab,int *elements){
    int *temp=malloc(sizeof(int) * (*elements));
    int max=*(tab),maxcount=0;
    printf("1");
    for (int i = 1; i < *elements; i++)
    {
        if (max<*(tab+i))
        {
            max=*(tab+i);
            maxcount=1;
        }
        else if (max==*(tab+i))
        {
            maxcount++;
        }
    }
    printf("\nmax count: %d",maxcount);
    *elements-= maxcount;
    int j=0;
    temp=realloc(temp,*elements*sizeof(int));
    
    for (int i = 0; i < *elements+maxcount; i++)
    {
        if (*(tab+i)!=max)
        {
            *(temp+j)=*(tab+i);
            j++;
        }   
    }
    
    
    printf("max : %d",max);
    return temp;
}

int * SupMin(int *tab,int *elements){
    int *temp=malloc(sizeof(int) * (*elements));
    int min=*(tab),mincount=0;
    printf("1");
    for (int i = 1; i < *elements; i++)
    {
        if (min>*(tab+i))
        {
            min=*(tab+i);
            mincount=1;
        }
        else if (min==*(tab+i))
        {
            mincount++;
        }
    }
    printf("\nmin count: %d",mincount);
    *elements-= mincount;
    int j=0;
    temp=realloc(temp,*elements*sizeof(int));
    
    for (int i = 0; i < *elements+mincount; i++)
    {
        if (*(tab+i)!=min)
        {
            *(temp+j)=*(tab+i);
            j++;
        }   
    }
    
    
    printf("\nmin : %d",min);
    return temp;
}
int * Ajout_pos(int *tab,int *elements){
    (*elements)++;
    printf("element: %d",*elements);
    int *temp=malloc(sizeof(int) * (*elements)),pos,number;
    printf("\nenter the position: ");
    scanf("%d",&pos);
    printf("enter a number: ");
    scanf("%d",&number);
    int j=0;
    
    for (int i = 0; i < *elements; i++)
    {
        if (i==pos)
        {   printf("qdq");
            *(temp+i)=number;
        }
        else
        {  
            *(temp+i)=tab[j];
            j++;
        }
        
        
    } 

    return temp;
}
void Moyenne(int *tab, int elements){
    float moy=0;
    for (int i = 0; i < elements; i++)
    {
        moy+=tab[i];
    }
    moy/=elements;
    printf("\nla moyenne est %f",moy);
    
}


int main(){

    char a;
    int elements=5;
    int *ptr=(int*)malloc(elements*sizeof(int));
    printf("%d",sizeof(ptr));
    begin:
    
    printf("\nA-Affichage");
    printf("\nB-Saisie");
    printf("\nC-Moyenne");
    printf("\nD-Suppression du Max");
    printf("\nE-Suppression du Min");
    printf("\nF-Ajout d'un entier a une position donnee");
    printf("\nG-Quitter\n");
    printf("qu'est ce vous voulez faire? \n");
    scanf(" %c",&a);
    switch (a)
    {
    case 'A':
        Affichage(ptr,elements);
        goto begin;
        getchar();
        break;
    case 'B':
        saisie(ptr,elements);
        goto begin;
        break;
    case 'C':
        Moyenne(ptr,elements);
        goto begin;
        break;
    case 'D':
        ptr=SupMax(ptr,&elements);
        
        printf("\n\t number of elements %d",elements);
        goto begin;
        break;
    case 'E':
        ptr=SupMin(ptr,&elements);
        printf("\n\t number of elements %d",elements);
        goto begin;
        break;
    case 'F':
        ptr=Ajout_pos(ptr,&elements);
        printf("\n\t number of elements %d",elements);
        goto begin;
        break;

    case 'Q':
        break;
    default:
    printf("\nlettre non valid !!");
    goto begin;
        break;
    }
    
free(ptr);
}