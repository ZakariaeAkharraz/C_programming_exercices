#include <stdio.h>
#include <string.h>
void saisie(char name[])
{
    printf("\nenter a name: ");
    scanf("%s", name);
}
int check(char name[]){
    int i=0;
    while (name[i]!='\0')
    {
        i++;
    }
    
return i;
}


int main()
{

    char name[20];
    int count=0;
    while (1)
    {
        saisie(name);
        if (strcmp(name, "fin") == 0)
        {
            break;
        }
        if (check(name)>=10)
        {
            count++;
        }
        
        printf("\nname: %s", name);
    }
    printf("\nnumber of 10 characters words : %d",count);
}