#include <stdio.h>
#include <string.h>
#include<stdlib.h>
void saisie(char name[])
{   
    printf("\nenter a name to search: ");
    scanf("%[^\n]%*c", name);
    
}
void phrase(char name[])
{   
    printf("\nenter a phrase: ");
    scanf("%[^\n]%*c", name);
    
}
int check_occ(char *Dep,char *check){
    int len=strlen(Dep),count=0;
    char *Arr;
    
    Arr=Dep+len-1;
    char temp;
    for (int i = 0; i <= len; i++)
    {
        if (*(Dep+i)==*(check))
        {
            for (int j = 0; j < strlen(check); j++)
            {
                if (*(Dep+i+j)!=*(check+j))
                    goto end;
            }
           count++; 
        }
        end:
    }
    return count;
    
    //printf("lenght: %d\tcount: %d",len,count);
    //printf("\nreversed: %s",Dep);

}

int main(){
char name[100];
phrase(name);
char search[20];
saisie(search);
printf("\nNumber of occurences: %d",check_occ(name,search));




}