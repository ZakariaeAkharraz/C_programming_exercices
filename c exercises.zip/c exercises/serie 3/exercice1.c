#include <stdio.h>
#include <string.h>
#include<stdlib.h>
void saisie(char name[])
{
    printf("\nenter a name: ");
    scanf("%s", name);
    
}
void inverse(char *Dep){
    int len=strlen(Dep);
    char *Arr;
    
    Arr=Dep+len-1;
    char temp;
    for (int i = 0; i <= len/2; i++)
    {
        temp=*(Arr-i);
        *(Arr-i)=*(Dep+i);
        *(Dep+i)=temp;
    }
    
    
    
    printf("\nreversed: %s",Dep);
}

int main(){
char name[30];
saisie(name);
inverse(name);



}