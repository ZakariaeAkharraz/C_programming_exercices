#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void saisir(char name[])
{   
    printf("enter a phrase: ");
    scanf("%[^\n]%*c", name);
    
}
void afficher(char*phrase){
    printf("\nla phrase est : %s",phrase);
}
void menu(){
    char w;
    printf("\npress a letter to go to menu: ");
    scanf(" %c",&w);
}
void inverse(char name[]){
    int len=strlen(name);
    char temp;
    for (int i = 1; i <= len/2; i++)
    {
        temp=name[len-i];
        name[len-i]=name[i-1];
        name[i-1]=temp;
    }
    printf("\nreversed: %s",name);
}

int main(){
char a;
char phrase[100];
char garbage;
begin:
printf("\nquelle operation vous voulez affecter: ");
printf("\nA-saisir une chaine de caracteres");
printf("\nB-afficher une chaine de caracteres");
printf("\nC-inverser une chaine de caracteres");
printf("Q-quitter\n");
scanf(" %c",&a);
switch (a)
{
case 'A':
    scanf("%c",&garbage);
    saisir(phrase);
    printf("\nla phrase est : %s",phrase);
    menu();
    goto begin;
    break;
case 'B':
    afficher(phrase);
    menu();
    goto begin;
    break;
    case 'C':
    inverse(phrase);
    menu();
    goto begin;
    break;
case 'Q':
    break;
default:
    printf("\nenter une lettre valid");
    menu();
    goto begin;
    break;
}


}