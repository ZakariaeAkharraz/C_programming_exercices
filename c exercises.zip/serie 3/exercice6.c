#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void saisie(char name[])
{
    printf("\nenter a name to search: ");
    scanf("%[^\n]%*c", name);
}
void phrase(char name[])
{
    printf("\nenter a phrase: ");
    scanf("%[^\n]%*c", name);
}
void delete_spaces(char *Dep)
{
    int len = strlen(Dep), count = 0;
    char Arr[len];
    int j = 0;
    char temp;
    for (int i = 0; i <= len; i++)
    {
        if (*(Dep + i) != ' ' && count == 0)
        {
            Arr[j] = *(Dep + i);
            j++;
        }
        else
        {
            while (*(Dep + i) == ' ' && count == 0)
            {
                i++;
            }
            count = 1;
            Arr[j] = *(Dep + i);
            j++;
        }
    }
    strcpy(Dep, Arr);
}

int main()
{
    char name[100];
    phrase(name);
    printf("\nbefore:%s", name);
    delete_spaces(name);
    printf("\nAfter:%s", name);
}