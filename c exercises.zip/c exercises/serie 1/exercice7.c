#include <stdio.h>



int main(){
//////////////////////////////////////////////////////
//1)
    int a,list[5];
    //printf("enter a number: ");
    //scanf("%d", &a);
    for (int i = 0; i < 5; i++)
        {
            printf("enter number %d: ",i+1);
            scanf("%d",&list[i]);
        }

    for (int i = 0; i < 5; i++)
    {
        if (list[i]%2==0) printf("%d\n",list[i]*list[i]);
    }
/////////////////////////////////////////////////////
//2)
int t[100],count,temp;
count=0;
for (int i = 0; i < 100; i++)
        {
            printf("enter number %d: ",i+1);
            scanf("%d",&temp);
            if (temp!=100)
            {   
                t[i]=temp;
                count++;
            }
            else break;
            
        }
for (int i = 0; i < count; i++)
{
    if (t[i]%2==0) printf("%d\n",t[i]*t[i]);
}
printf("\nnumber of elements is %d",count);

}