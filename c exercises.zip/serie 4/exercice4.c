#include <stdio.h>


struct repertoire{
    char nom[15],prenom[15];
    int telephone;
};
void affichage(struct repertoire emp[],int nbr){
    for (int i = 0; i < nbr; i++)
    {
        printf("\nNom: %s",emp[i].nom);
        printf("\nPrenom: %s",emp[i].prenom);
        printf("\nNumero de telephone: %d",emp[i].telephone);
    }
}
int main(){
    int nbr;
    printf("combien de persons tu veux inserer? ");
    scanf("%d",&nbr);
    struct repertoire emp[nbr];
    for (int i = 0; i < nbr; i++)
    {
        printf("entrer les informations d'employee %d",i+1);
        printf("\nnom: ");
        scanf("%s",emp[i].nom);
        printf("prenom: ");
        scanf("%s",emp[i].prenom);
        printf("Numero de telephone: ");
        scanf("%d",&emp[i].telephone);
        printf("\n\ttelephone: %d\n",emp[i].telephone);
    }
    
    affichage(emp,nbr);
    
}