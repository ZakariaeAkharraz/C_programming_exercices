#include<stdio.h>
#include<stdlib.h>

typedef struct panneau
{
    float longueur,largeur,epaisseur;
    int type;
}panneau;
panneau saisie(){
    panneau p_bois;
    printf("entrer la longueur du bois: ");
    scanf("%f",&p_bois.longueur);
    printf("entrer la largeur du bois: ");
    scanf("%f",&p_bois.largeur);
    printf("entrer l'epaisseur du bois: ");
    scanf("%f",&p_bois.epaisseur);
    printf("choisi le type du bois: Pin=0, chene=1, hetre=2: ");
    scanf("%d",&p_bois.type);
    printf("\nlongueur: %f\tlargeur: %f,\tepaisseur: %f",p_bois.longueur,p_bois.largeur,p_bois.epaisseur);
    printf("\nle type: ");
    if (p_bois.type==0)
    printf("Pin");
    else if(p_bois.type==1)
    printf("chene");
    else
    printf("hetre");
    return p_bois;
}
float cal_volum(panneau bois){
    float volum;
    volum=(bois.epaisseur/1000)*(bois.longueur/1000)*(bois.largeur/1000);
    return volum;
}
int main(){
panneau p_bois;
p_bois=saisie();
float volume=cal_volum(p_bois);
printf("\nla volume : %f metres cube",volume);
}