#include <stdio.h>



int main(){

    int a;
    printf("enter a number: ");
    scanf("%d", &a);
    if(a%2!=0)
    a++;
    
    for (int i = 0; i <= a; i++)
    {
        for (int j = 0; j <= a; j++)
        {
            if (i==0||(i>0 && (j==0 || j==a))||i==a)
            {
                printf("* ");
            }
            else if (i==j||i==a-j)
            {
                printf("+ ");
            }
            else if ((int)a/2==(int)j)
            {
                printf("- ");
            }
            else if ((int)a/2==(int)i)
            {
                printf("| ");
            }
            
            
            
            else printf("  ");
        }
        printf("\n");
        
    }
    
    

}