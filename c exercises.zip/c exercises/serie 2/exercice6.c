#include <stdio.h>
#include <string.h>
#include<stdlib.h>


int main(){
char ctab1[]="lad2345s\t and gentlment\n";
int chiffres,espacement,autres;
chiffres=0;
espacement=0;
autres=0;
for (int i = 0; i < strlen(ctab1); i++)
{
    if(ctab1[i]>=48 && ctab1[i]<=57)
    chiffres++;
    else if(ctab1[i]==' '||ctab1[i]=='\n'||ctab1[i]=='\t')
    espacement++;
    else autres++;
}
printf("Chiffrement: %d\tEspacement: %d\tAutres: %d",chiffres,espacement,autres);


//crypted_nam=(char*)malloc(sizeof(char)*strlen(name));


}