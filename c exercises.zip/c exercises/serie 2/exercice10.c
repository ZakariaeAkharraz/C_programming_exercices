#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int distanceH(char s1[], char s2[])
{
    int len = strlen(s1), count = 0;
    for (int i = 0; i < len; i++)
    {
        if (s1[i] != s2[i])
            count++;
    }
    return count;
}
int distanceH_langage(int n, char language[][n])
{
    int len = (strlen(language[0]) - 1) / n, count = 0, distance = 4;

    for (int i = 0; i < len - 2; i++)
    {
        for (int j = i+1; j < len - 1; j++)
        {
            for (int k = 0; k < n; k++)
            {


                if (language[i][k] != language[j][k])
                {

                    count++;
                }
            }
        if (distance>count)
        {
            distance=count;
        }
        count = 0;
            // printf("\ndistance: %d\n", distance);
        }
    }
    return distance;
}
char* binaire(int n){
    int temp=n;
    printf("\n");
    char *nb_binaire=malloc(sizeof(char)*9);
    for (int i = 0; i < 8; i++)
    {
        if (temp>=1)
        {
            if(temp%2==0)
            nb_binaire[i]='0';
            else
            nb_binaire[i]='1';
        }
        else
        nb_binaire[i]='0';

        temp/=2;
        
    }
    strcpy(nb_binaire,strrev(nb_binaire));
    //printf("ad");
    //printf("\n%s",nb_binaire);
    return nb_binaire;
}
int distanccNombre(int A,int B){
    char *A_bin,*B_bin;
    A_bin=binaire(A);
    B_bin=binaire(B);
    return distanceH(A_bin,B_bin);
}
int main()
{

    char language[][4] = {"aabb", "xayy", "tghy", "xgyy"};
    printf("distance entre sure et cure: %d\n", distanceH("sure", "cure"));
    printf("\ndistance language: %d", distanceH_langage(4, language));
    printf("distance bin entre 4 et 5: %d",distanccNombre(4,5));
}