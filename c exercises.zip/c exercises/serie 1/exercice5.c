#include <stdio.h>
#include <math.h>

int main()
{

    int a;
    printf("enter a number: \n");
    scanf("%d", &a);
    for (int i = 2; i <= sqrt(a); i++)
    {
        if (a % i == 0)
        {
            printf("le nombre %d nest pas premier", a);
            goto end;
        }
    }
    printf("le nombre %d est premier", a);
end:
}