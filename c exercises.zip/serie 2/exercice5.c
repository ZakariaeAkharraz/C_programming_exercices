#include <stdio.h>
#include <string.h>
#include<stdlib.h>
void saisie(char name[])
{
    printf("\nenter a name: ");
    scanf("%s", name);
    
}
void cryptage(char name[],char crypted[]){
    strcpy(crypted,name);
    int a;
    for (int i = 0; i < strlen(name); i++)
    {   a=(int)name[i];
       
        if ((name[i]<86&&name[i>=65])||(name[i]>=97&&name[i]<118))
        {
            crypted[i]=name[i]+5;
            printf("\n i= %c",crypted[i]);
        }
        else if (name[i]>=86&&name[i]<=90)
        {   
            crypted[i]='A'-(90-(a+5));
        }
        else if (name[i]>=118&&name[i]<=122)
        {
            
            crypted[i]='a'-(122-(a+5));
        }
       
    }

}
int main(){
char name[20],crypted_nam[20];

saisie(name);
//crypted_nam=(char*)malloc(sizeof(char)*strlen(name));
cryptage(name,crypted_nam);
printf("\nbefore cryption: %s",name);
printf("\nafter cryption: %s",crypted_nam);

}