#include <stdio.h>



int main(){

    int a;
    printf("enter a number: ");
    scanf("%d", &a);
    
    for (int i = 1; i <= a; i++)
    {
        for (int j = 1; j <= a; j++)
        {
            if (i==1||(i>1 && (j==1 || j==a))||i==a)
            {
                printf("*");
            }
            else if (i==j||i==a-j)
            {
                printf("+");
            }
            else if ((int)a/2==(int)j)
            {
                printf("-");
            }
            else if ((int)a/2==(int)i)
            {
                printf("|");
            }
            
            
            
            else printf(" ");
        }
        printf("\n");
        
    }
    
    

}