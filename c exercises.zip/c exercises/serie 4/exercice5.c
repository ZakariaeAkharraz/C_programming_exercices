#include <stdio.h>
#include<stdlib.h>
int nb_occurences(char T[], int n, char c)
{
    int p_occ = -1, d_occ = -1, count = 0;

    for (int i = 0; i < n; i++)
    {
        if (T[i] == c)
        {
            if (p_occ == -1)
            {
                p_occ = i;
                d_occ = i;
                count++;
            }
            else
            {
                d_occ = i;
                count++;
            }
        }
    }
    printf("p_occ: %d\td_occ: %d", p_occ, d_occ);
    return count;
}
int pos_car(char T[], int n, char c, int *p_occ, int *d_occ)
{
    int count = 0;
    *p_occ=-1;
    *d_occ=-1;
    for (int i = 0; i < n; i++)
    {
        if (T[i] == c)
        {
            if (*p_occ == -1)
            {
                *p_occ = i;
                *d_occ = i;
                count++;
            }
            else
            {
                *d_occ = i;
                count++;
            }
        }
    }
    // printf("p_occ: %d\td_occ: %d", p_occ, d_occ);
    return count;
}
int main()
{

    char name[] = "i will find you and i will kill you";
    char c = 'l';
    int *p_occ=malloc(sizeof(int)), *d_occ=malloc(sizeof(int));
    
    int count = pos_car(name, 36, c,p_occ,d_occ);
    printf("\nnumber of occurences: %d", count);
    printf("\np_occ: %d\td_occ: %d",*p_occ,*d_occ);
}