#include <stdio.h>

struct date
{
    int jour,annee; char mois[10];
};
struct employe{
    char nom[15],prenom[15];
    struct date date_naissance,date_embauche;
};
int main(){
    struct employe emp[4];
    for (int i = 0; i < 4; i++)
    {
        printf("\nentrer les informations d'employee %d",i+1);
        printf("\nnom: ");
        scanf("%s",emp[i].nom);
        printf("\nprenom: ");
        scanf("%s",emp[i].prenom);
        printf("\ndate de naissance: ");
        printf("\njour: ");
        scanf("%d",&emp->date_naissance.jour);
        printf("mois: ");
        scanf("%s",emp->date_naissance.mois);
        printf("annee: ");
        scanf("%d",&emp->date_naissance.annee);
        printf("\ndate d'embauche: ");
        printf("\njour: ");
        scanf("%d",&emp->date_embauche.jour);
        printf("mois: ");
        scanf("%s",emp->date_embauche.mois);
        printf("annee: ");
        scanf("%d",&emp->date_embauche.annee);

    }
    printf("\nla date: %d/%s/%d",emp->date_embauche.jour,emp->date_embauche.mois,emp->date_embauche.annee);
    for (int i = 0; i < 4; i++)
    {
        printf("\nNom: %s",emp[i].nom);
        printf("\nPrenom: %s",emp[i].prenom);
        printf("\ndate de naissance : %d %s %d",emp[i].date_naissance.jour,emp[i].date_naissance.mois,emp[i].date_naissance.annee);
        printf("\ndate d'embauche : %d %s %d",emp[i].date_embauche.jour,emp[i].date_embauche.mois,emp[i].date_embauche.annee);
    }
    
}