#include <stdio.h>

struct etudiant
{
    char nom[15], prenom[15];
    int CNE;
    float notes[4], moyenne;
    
};
void afficher(int pos, struct etudiant T[])
{
    printf("\nnom: %s", T[pos].nom);
    printf("\nprenom: %s", T[pos].prenom);
    printf("\nCNE: %d", T[pos].CNE);
    for (int j = 0; j < 4; j++)
    {
        printf("\nnote %d: %f ", j + 1, T[pos].notes[j]);
    }
    printf("\nMoyenne: %f", T[pos].moyenne);
}
int main()
{
    struct etudiant T[5];
    for (int i = 0; i < 5; i++)
    {
        printf("\nentrer les informations d'etudiant %d", i + 1);
        printf("\nnom: ");
        scanf("%s", T[i].nom);
        printf("\nprenom: ");
        scanf("%s", T[i].prenom);
        printf("\nCNE: ");
        scanf("%d",&T[i].CNE);
        
        T[i].moyenne=(float)0;
        
        for (int j = 0; j < 4; j++)
        {
            printf("\nnote %d: ", j + 1);
            scanf("%f",&T[i].notes[j]);
            T[i].moyenne += T[i].notes[j];
        }
        T[i].moyenne /= 4;
    }
    int max = T[0].moyenne, pos = 0;
    for (int i = 0; i < 5; i++)
    {
        if (max < T[i].moyenne)
        {
            max = T[i].moyenne;
            pos++;
        }
    }
    afficher(pos, T);
    struct etudiant temp;
    temp = T[pos];
    T[pos] = T[0];
    T[0] = temp;
    max = T[1].moyenne;
    for (int i = 1; i < 5; i++)
    {
        for (int j = i; j < 5; j++)
        {
            if (max < T[j].moyenne)
            {   max=T[j].moyenne;
                temp = T[j];
                T[j] = T[i];
                T[i] = temp;

            }
        }
    }
    for (int i = 0; i < 5; i++)
    {
        printf("\n moyenne: %f",T[i].moyenne);
    }
    
}