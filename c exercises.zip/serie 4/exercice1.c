#include <stdio.h>

typedef struct complex
{
    double real;
    double imag;
}complex;

double imag(complex a){
return a.imag;
}
double real(complex a){
return a.real;
}
complex mul(complex z1,complex z2){
complex z3;
z3.real=z1.real*z2.real-z1.imag*z2.imag;
z3.imag=z1.real*z2.imag+z1.imag*z2.real;
return z3;
}
double imag_pointer(complex *a){
return a->imag;
}
double real_pointer(complex *a){
return a->real;
}
complex mul_pointer(complex *z1,complex *z2){
complex z3;

z3.real=z1->real * z2->real-z1->imag * z2->imag;
z3.imag=z1->real*z2->imag+z1->imag*z2->real;
return z3;
}

int main(){


}