#include <stdio.h>
#include <stdlib.h>

typedef struct produit
{
    int type;
    int stock;
    int reference;
    float prix;
} produit;
produit saisie()
{
    produit prd;
    printf("choisi le type du composant: carte mere=1, processeur=2\nbarrette memoir=3:, carte graphique:4 ");
    scanf("%d", &prd.type);
    printf("saisie la reference du composant: ");
    scanf("%d", &prd.reference);
    printf("saisie le prix: ");
    scanf("%f", &prd.prix);
    printf("saisie la quantite du stock: ");
    scanf("%d", &prd.stock);

    printf("\nle produit: ");
    if (prd.type == 1)
        printf("carte mere");
    else if (prd.type == 2)
        printf("processeur");
    else if (prd.type == 3)
        printf("barrette memoir");
    else
        printf("carte graphique");
    printf("\nreference: %d\nprix: %f dhs\nstock:%d", prd.reference, prd.prix, prd.stock);
    return prd;
}
float prix_command(produit prd[],int n)
{
    int type, quantitee;
    float total;
    printf("que'est ce que tu veux acheter?\ncarte mere=1, processeur=2\nbarrette memoir=3:, carte graphique:4\n");
    scanf("%d", &type);
    printf("saisie la quantitee");
    scanf("%d", &quantitee);
    for (int i = 0; i < n; i++)
    {
        if (type==prd[i].type){
            if (quantitee<prd[i].stock)
            {
                printf("\ncette quantitee n'est pas dans le stock");
                break;
            }
            else
            {
                total=prd[i].prix*quantitee;
                printf("le prix total est: %f",total);
            }
            
            
        }
    }
    
}
int main()
{
    int n;
    printf("combien de produits tu veux saisir? ");
    scanf("%d",&n);
    produit prd[n]; 
    for (int i = 0; i < n; i++)
    {
        prd[i]=saisie();
    }
    
}