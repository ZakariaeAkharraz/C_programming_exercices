#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int addition(int a, int b){
    return a+b;
}
int soustraction(int a, int b){
    return a-b;
}
int multiplication(int a, int b){
    return a*b;
}
int modulo(int a, int b){
    return a%b;
}
int division(int a, int b){
    if (b==0)
    {
        printf("\noperation impossible");
        return 0;
    }
    
    return a/b;
}
int main(){

    char operation[20],operator,num1[5],num2[5],pos,reponse;
    int nbr1,nbr2,result;
    begin:
    printf("enter an operation: ");
    scanf("%s",operation);
    for (int i = 0; i < strlen(operation); i++)
    {
        if (operation[i]<48 || operation[i]>57)
        {
            operator=operation[i];
            pos=i;
            break;
        }
        
    }
    printf("\noperator: %c",operator);
    for ( int i=0 ; i < strlen(operation); i++)
    {
        if (i<pos)
        {
            num1[i]=operation[i];
            num2[i]=operation[i+pos+1];
        }
        
        
    }
    printf("\nnumber1: %s, number2: %s",num1,num2);
    nbr1=atoi(num1);
    nbr2=atoi(num2);
    switch (operator)
    {
    case '+':
        result=addition(nbr1,nbr2);
        break;
    case '-':
        result=soustraction(nbr1,nbr2);
        break;
    case '*':
        result=multiplication(nbr1,nbr2);
        break;
    case '/':
        result=division(nbr1,nbr2);
        break;
    case '%':
        result=modulo(nbr1,nbr2);
        break;
    default:
        break;
    }
    printf("\n%s= %d",operation,result);
    printf("\ntu veux ressayer:  'O' ou 'N'  ?");
    scanf(" %c",&reponse);
    if(reponse=='O')
    goto begin;
    
}