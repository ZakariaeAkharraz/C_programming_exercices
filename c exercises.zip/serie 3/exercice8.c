#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    int *tab = malloc(1 * sizeof(int)), *compressed=malloc(1 * sizeof(int)), count = 0, temp, j = 0;
    int len = 0;
    
    do
    {
        tab = realloc(tab, (len + 1) * sizeof(int));
        printf("enter one number %d: ", len + 1);
        scanf("%d", tab + len);
        len++;
    } while (*(tab + len - 1) != 0);
    printf("\n non: %d", *(tab + len - 1));
    temp = tab[0];
    for (int i = 0; i <= len; i++)
    {
        if (temp == *(tab + i))
        {
            count++;
        }
        else
        {   compressed = realloc(tab, (j + 2) * sizeof(int));
            *(compressed+j) = count;
            *(compressed+j + 1) = temp;
            
            j += 2;
            temp = *(tab + i);
            count = 1;
        }
    }
    printf("\ncompressed : ");
    for (int i = 0; i < j; i++)
    {
        printf("%d", *(compressed+i));
    }
}