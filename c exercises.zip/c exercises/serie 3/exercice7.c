#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int search_target(float tab[],float target,int size){
    for (int i = 0; i < size; i++)
    {
        if (tab[i]==target)
        {
            return i;
        }
        
    }
    return -1;
}
int main()
{
    int size;
    printf("enter the lengh of the array: ");
    scanf("%d", &size);
    float a = 12.43, tab[size], target;

    for (int i = 0; i < size; i++)
    {
        printf("\nenter number %d: ", i + 1);
        scanf("%f", &tab[i]);
    }
    printf("\n what number are you looking for: ");
    scanf("%f", &target);
    int check=search_target(tab,target,size);
    printf("number we're looking for : %f",target,check);
    if (check==-1)
    {
        printf("\nthis number doesn't exist");
    }
    else printf("\nit's position: %d",check);
    
}