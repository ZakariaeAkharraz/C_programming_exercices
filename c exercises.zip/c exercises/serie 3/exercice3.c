#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include<time.h>
float somme_indice(float t[3][4]){
    float sum=0;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            sum+=t[i][j];
        }
        
    }
    return sum;
}
float somme_pointer(float (*p)[4]){
    float sum=0,*ptr=&p[0][0];
    for (int i = 0; i < 12; i++)
    {
        sum+= *ptr;
        ptr++;
    }
    
    return sum;
}

int main(){
float t[3][4],somme;

 t[0][0]=1.000000;
 t[0][1]=2.000000;
 t[0][2]=3.000000;
 t[0][3]=4.000000;
 t[1][0]=5.000000;
 t[1][1]=6.000000;
 t[1][2]=7.000000;
 t[1][3]=8.000000;
 t[2][0]=9.000000;
 t[2][1]=0.000000;
 t[2][2]=-9.000000;
 t[2][3]=-8.000000;
somme=somme_indice(t);
printf("\nla somme est: %f",somme);
somme=0;
somme=somme_pointer(t);
printf("\nla somme est: %f",somme);

}