#include <stdio.h>
#include <string.h>
#include<stdlib.h>
void saisie(char name[])
{   
    printf("\nenter a name: ");
    scanf("%s", name);
    
}
int check_palindrome(char *Dep){
    int len=strlen(Dep),count=0;
    char *Arr;
    
    Arr=Dep+len-1;
    char temp;
    for (int i = 0; i <= len/2; i++)
    {
        if(*(Arr-i)==*(Dep+i))
        count++;
        else
        {
            
            goto end;
        }
        
    }
    return 1;
    
    //printf("lenght: %d\tcount: %d",len,count);
    end:
    return 0;
    //printf("\nreversed: %s",Dep);

}

int main(){
char name[30];
saisie(name);
if (check_palindrome(name)==1)
{
    printf("\nle mot %s est un palindrome",name);
}
else
{
    printf("\nle mot %s n'est un palindrome",name);
}




}